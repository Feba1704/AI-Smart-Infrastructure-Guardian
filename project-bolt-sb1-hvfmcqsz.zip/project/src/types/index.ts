export type RiskLevel = 'healthy' | 'warning' | 'critical';
export type StructureType = 'bridge' | 'building' | 'tunnel' | 'dam' | 'tower' | 'stadium';
export type SensorStatus = 'online' | 'offline' | 'calibrating';

export interface SensorReading {
  vibration: number;
  strain: number;
  movement: number;
  temperature: number;
  load: number;
}

export interface SensorTrend {
  timestamp: string;
  vibration: number;
  strain: number;
  movement: number;
  temperature: number;
  load: number;
}

export interface Structure {
  id: string;
  name: string;
  type: StructureType;
  location: string;
  lat: number;
  lng: number;
  healthScore: number;
  riskLevel: RiskLevel;
  sensorStatus: SensorStatus;
  sensorCount: number;
  activeSensors: number;
  lastInspection: string;
  builtYear: number;
  readings: SensorReading;
  anomalyScore: number;
  deviationPercent: number;
  riskProbability: number;
  predictionWindow: string;
  aiSummary: string;
  trend: SensorTrend[];
  learnedNormal: SensorTrend[];
  currentBehavior: SensorTrend[];
}

export interface Alert {
  id: string;
  structureId: string;
  structureName: string;
  issue: string;
  severity: RiskLevel;
  timestamp: string;
  confidence: number;
  sensor: string;
  status: 'active' | 'acknowledged' | 'resolved';
  recommendation: string;
}

export interface MaintenanceItem {
  id: string;
  structureId: string;
  structureName: string;
  predictedIssue: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  recommendedInspection: string;
  urgency: string;
  estimatedCost: string;
  predictedDate: string;
  confidence: number;
  status: 'scheduled' | 'in-progress' | 'completed' | 'pending';
}

export interface ReportItem {
  id: string;
  title: string;
  type: 'health-trend' | 'anomaly' | 'prediction' | 'maintenance-history';
  structureName: string;
  date: string;
  summary: string;
  dataPoints: number;
  status: 'generated' | 'scheduled' | 'archived';
}

export interface AIPrediction {
  id: string;
  structureName: string;
  prediction: string;
  probability: number;
  window: string;
  confidence: number;
}
