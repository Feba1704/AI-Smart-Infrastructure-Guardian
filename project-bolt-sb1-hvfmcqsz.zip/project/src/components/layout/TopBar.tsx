import { Search, Bell, Activity } from 'lucide-react';
import type { PageId } from '@/types/nav';

interface TopBarProps {
  current: PageId;
  alertCount: number;
  onNavigate: (page: PageId) => void;
}

const titles: Record<PageId, { title: string; subtitle: string }> = {
  dashboard: { title: 'Dashboard', subtitle: 'Portfolio overview and real-time health monitoring' },
  infrastructure: { title: 'Infrastructure', subtitle: 'All monitored structures and their status' },
  'structure-details': { title: 'Structure Details', subtitle: 'In-depth structural health analysis' },
  'live-monitoring': { title: 'Live Monitoring', subtitle: 'Real-time sensor data vs learned normal behavior' },
  'ai-analysis': { title: 'AI Analysis', subtitle: 'Anomaly detection and risk prediction pipeline' },
  alerts: { title: 'Alerts', subtitle: 'Active and historical anomaly alerts' },
  maintenance: { title: 'Predictive Maintenance', subtitle: 'AI-driven maintenance recommendations' },
  reports: { title: 'Reports', subtitle: 'Health trends, anomalies, and maintenance history' },
};

export default function TopBar({ current, alertCount, onNavigate }: TopBarProps) {
  const t = titles[current];
  const now = new Date();
  const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });

  return (
    <header className="bg-white border-b border-gray-200 px-6 py-3.5 flex items-center justify-between sticky top-0 z-30">
      <div>
        <h2 className="text-lg font-bold text-navy-900">{t.title}</h2>
        <p className="text-xs text-gray-400">{t.subtitle}</p>
      </div>

      <div className="flex items-center gap-3">
        {/* Search */}
        <div className="relative hidden md:block">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search structures..."
            className="w-56 bg-gray-50 border border-gray-200 rounded-lg pl-9 pr-3 py-2 text-sm text-navy-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-navy-300 transition-all"
          />
        </div>

        {/* Live status */}
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-success-50 border border-success-200">
          <span className="relative flex">
            <span className="w-2 h-2 rounded-full bg-success-500 animate-ping-slow absolute" />
            <span className="w-2 h-2 rounded-full bg-success-500 relative" />
          </span>
          <span className="text-xs font-semibold text-success-700">Live</span>
        </div>

        {/* System time */}
        <div className="hidden lg:flex items-center gap-2 px-3 py-2 rounded-lg bg-gray-50 border border-gray-200">
          <Activity className="w-4 h-4 text-navy-500" />
          <span className="text-xs font-semibold text-navy-700 font-mono">{timeStr} UTC</span>
        </div>

        {/* Alerts */}
        <div
          className="relative w-10 h-10 rounded-lg bg-gray-50 border border-gray-200 flex items-center justify-center cursor-pointer hover:bg-gray-100 transition-all"
          onClick={() => onNavigate('alerts')}
        >
          <Bell className="w-5 h-5 text-navy-600" />
          {alertCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4.5 h-4.5 rounded-full bg-danger-500 text-white text-[10px] font-bold flex items-center justify-center" style={{ minWidth: 18, height: 18 }}>
              {alertCount}
            </span>
          )}
        </div>
      </div>
    </header>
  );
}
