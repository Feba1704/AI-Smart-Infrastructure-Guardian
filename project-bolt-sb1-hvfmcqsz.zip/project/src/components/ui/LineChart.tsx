interface LineChartSeries {
  name: string;
  data: number[];
  color: string;
  dashed?: boolean;
}

interface LineChartProps {
  series: LineChartSeries[];
  labels: string[];
  height?: number;
  yLabel?: string;
  showLegend?: boolean;
  showArea?: boolean;
  unit?: string;
}

export default function LineChart({ series, labels, height = 200, yLabel, showLegend = true, showArea = true, unit = '' }: LineChartProps) {
  const width = 600;
  const padding = { top: 20, right: 20, bottom: 30, left: 40 };
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  const allValues = series.flatMap(s => s.data);
  const minVal = Math.min(...allValues, 0);
  const maxVal = Math.max(...allValues) * 1.15;
  const range = maxVal - minVal || 1;

  const xStep = chartW / Math.max(labels.length - 1, 1);
  const yScale = (v: number) => chartH - ((v - minVal) / range) * chartH;

  const toPath = (data: number[]) =>
    data.map((v, i) => `${i === 0 ? 'M' : 'L'} ${padding.left + i * xStep} ${padding.top + yScale(v)}`).join(' ');

  const toAreaPath = (data: number[]) =>
    `${toPath(data)} L ${padding.left + (data.length - 1) * xStep} ${padding.top + chartH} L ${padding.left} ${padding.top + chartH} Z`;

  const yTicks = 4;
  const tickValues = Array.from({ length: yTicks + 1 }, (_, i) => minVal + (range * i) / yTicks);

  return (
    <div className="w-full">
      {showLegend && (
        <div className="flex items-center gap-4 mb-3 flex-wrap">
          {series.map(s => (
            <div key={s.name} className="flex items-center gap-2">
              <span className="w-4 h-0.5 rounded" style={{ backgroundColor: s.color, borderTop: s.dashed ? `2px dashed ${s.color}` : 'none', height: s.dashed ? 0 : 2 }} />
              <span className="text-xs font-medium text-gray-600">{s.name}</span>
            </div>
          ))}
        </div>
      )}
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ height }} preserveAspectRatio="none">
        {tickValues.map((tv, i) => (
          <g key={i}>
            <line x1={padding.left} y1={padding.top + yScale(tv)} x2={width - padding.right} y2={padding.top + yScale(tv)} stroke="#f1f5f9" strokeWidth={1} />
            <text x={padding.left - 8} y={padding.top + yScale(tv) + 4} textAnchor="end" className="fill-gray-400" style={{ fontSize: 10 }}>
              {tv.toFixed(0)}{unit}
            </text>
          </g>
        ))}
        {labels.map((l, i) => (
          <text key={i} x={padding.left + i * xStep} y={height - 8} textAnchor="middle" className="fill-gray-400" style={{ fontSize: 10 }}>
            {l}
          </text>
        ))}
        {series.map(s => (
          <g key={s.name}>
            {showArea && !s.dashed && (
              <path d={toAreaPath(s.data)} fill={s.color} opacity={0.08} />
            )}
            <path
              d={toPath(s.data)}
              fill="none"
              stroke={s.color}
              strokeWidth={2}
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeDasharray={s.dashed ? '5 4' : 'none'}
            />
          </g>
        ))}
      </svg>
      {yLabel && <span className="text-xs text-gray-400 mt-1 block">{yLabel}</span>}
    </div>
  );
}
