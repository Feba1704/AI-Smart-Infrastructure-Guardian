import { useState } from 'react';
import { AlertTriangle, CheckCircle2, Clock, ChevronRight, Filter, Bell, ArrowRight } from 'lucide-react';
import type { Alert, RiskLevel } from '@/types';
import type { PageId } from '@/types/nav';
import RiskBadge from '@/components/ui/Badge';

interface AlertsScreenProps {
  alerts: Alert[];
  onNavigate: (page: PageId) => void;
}

const statusConfig = {
  active: { label: 'Active', classes: 'bg-danger-100 text-danger-700', dot: 'bg-danger-500' },
  acknowledged: { label: 'Acknowledged', classes: 'bg-warning-100 text-warning-700', dot: 'bg-warning-500' },
  resolved: { label: 'Resolved', classes: 'bg-success-100 text-success-700', dot: 'bg-success-500' },
};

export default function AlertsScreen({ alerts, onNavigate }: AlertsScreenProps) {
  const [filter, setFilter] = useState<'all' | RiskLevel>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'acknowledged' | 'resolved'>('all');

  const filtered = alerts.filter(a => {
    const matchRisk = filter === 'all' || a.severity === filter;
    const matchStatus = statusFilter === 'all' || a.status === statusFilter;
    return matchRisk && matchStatus;
  });

  const activeCount = alerts.filter(a => a.status === 'active').length;
  const ackCount = alerts.filter(a => a.status === 'acknowledged').length;
  const resolvedCount = alerts.filter(a => a.status === 'resolved').length;

  return (
    <div className="p-6 space-y-5 animate-fade-in">
      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-danger-100 flex items-center justify-center"><AlertTriangle className="w-5 h-5 text-danger-600" /></div>
          <div><p className="metric-label">Active</p><p className="text-xl font-bold text-danger-600">{activeCount}</p></div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-warning-100 flex items-center justify-center"><Clock className="w-5 h-5 text-warning-600" /></div>
          <div><p className="metric-label">Acknowledged</p><p className="text-xl font-bold text-warning-600">{ackCount}</p></div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-success-100 flex items-center justify-center"><CheckCircle2 className="w-5 h-5 text-success-600" /></div>
          <div><p className="metric-label">Resolved</p><p className="text-xl font-bold text-success-600">{resolvedCount}</p></div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-navy-100 flex items-center justify-center"><Bell className="w-5 h-5 text-navy-600" /></div>
          <div><p className="metric-label">Total</p><p className="text-xl font-bold text-navy-900">{alerts.length}</p></div>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-4">
        <div className="flex items-center gap-3 flex-wrap">
          <Filter className="w-4 h-4 text-gray-400" />
          <div className="flex gap-1.5">
            {(['all', 'critical', 'warning', 'healthy'] as const).map(r => (
              <button
                key={r}
                onClick={() => setFilter(r)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${filter === r
                  ? r === 'critical' ? 'bg-danger-500 text-white' : r === 'warning' ? 'bg-warning-500 text-white' : r === 'healthy' ? 'bg-success-500 text-white' : 'bg-navy-700 text-white'
                  : 'bg-gray-50 text-gray-500 hover:bg-gray-100'}`}
              >
                {r === 'all' ? 'All Severity' : r.charAt(0).toUpperCase() + r.slice(1)}
              </button>
            ))}
          </div>
          <div className="w-px h-6 bg-gray-200" />
          <div className="flex gap-1.5">
            {(['all', 'active', 'acknowledged', 'resolved'] as const).map(st => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${statusFilter === st ? 'bg-navy-700 text-white' : 'bg-gray-50 text-gray-500 hover:bg-gray-100'}`}
              >
                {st === 'all' ? 'All Status' : st.charAt(0).toUpperCase() + st.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Alert list */}
      <div className="space-y-3">
        {filtered.map(alert => {
          const sc = statusConfig[alert.status];
          return (
            <div key={alert.id} className="card-hover p-4 animate-slide-up">
              <div className="flex items-start gap-4">
                <div className={`w-1 h-full min-h-[60px] rounded-full ${alert.severity === 'critical' ? 'bg-danger-500' : alert.severity === 'warning' ? 'bg-warning-500' : 'bg-success-500'}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="text-sm font-bold text-navy-900">{alert.structureName}</span>
                    <RiskBadge level={alert.severity} />
                    <span className={`badge ${sc.classes}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                      {sc.label}
                    </span>
                    <span className="text-[10px] text-gray-400 font-mono">{alert.id}</span>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{alert.issue}</p>
                  <div className="flex items-center gap-4 flex-wrap">
                    <span className="text-xs text-gray-400 flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{alert.timestamp}</span>
                    <span className="text-xs text-gray-400">Sensor: {alert.sensor}</span>
                    <span className="text-xs font-semibold text-navy-600">Confidence: {alert.confidence}%</span>
                  </div>
                  <div className="mt-2 p-2.5 rounded-lg bg-gray-50 border border-gray-100">
                    <p className="text-xs text-gray-500"><span className="font-semibold text-navy-700">Recommendation:</span> {alert.recommendation}</p>
                  </div>
                </div>
                <div className="flex flex-col gap-2 shrink-0">
                  {alert.status === 'active' && (
                    <button className="btn-secondary text-xs px-3 py-1.5">Acknowledge</button>
                  )}
                  <button onClick={() => onNavigate('maintenance')} className="btn-teal text-xs px-3 py-1.5 flex items-center gap-1">
                    Maintenance <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="card p-12 text-center">
          <CheckCircle2 className="w-10 h-10 text-success-300 mx-auto mb-3" />
          <p className="text-sm font-semibold text-gray-500">No alerts match your filters</p>
          <p className="text-xs text-gray-400 mt-1">All clear — try adjusting filters</p>
        </div>
      )}
    </div>
  );
}
