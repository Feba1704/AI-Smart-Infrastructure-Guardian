interface DonutChartProps {
  data: { label: string; value: number; color: string }[];
  size?: number;
  thickness?: number;
  centerLabel?: string;
  centerValue?: string | number;
}

const colorMap: Record<string, string> = {
  success: '#10b981',
  warning: '#f59e0b',
  danger: '#ef4444',
  navy: '#3a5a9e',
  teal: '#1f9d92',
  gray: '#94a3b8',
};

export default function DonutChart({ data, size = 160, thickness = 24, centerLabel, centerValue }: DonutChartProps) {
  const radius = (size - thickness) / 2;
  const circumference = 2 * Math.PI * radius;
  const total = data.reduce((sum, d) => sum + d.value, 0) || 1;

  let offset = 0;
  const segments = data.map(d => {
    const fraction = d.value / total;
    const dash = fraction * circumference;
    const seg = {
      color: colorMap[d.color] || d.color,
      dasharray: `${dash} ${circumference - dash}`,
      dashoffset: -offset,
    };
    offset += dash;
    return seg;
  });

  return (
    <div className="flex items-center gap-4">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#f1f5f9" strokeWidth={thickness} />
          {segments.map((s, i) => (
            <circle
              key={i}
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="none"
              stroke={s.color}
              strokeWidth={thickness}
              strokeDasharray={s.dasharray}
              strokeDashoffset={s.dashoffset}
              style={{ transition: 'stroke-dashoffset 1s ease-out' }}
            />
          ))}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          {centerValue !== undefined && <span className="text-2xl font-bold text-navy-900">{centerValue}</span>}
          {centerLabel && <span className="text-xs text-gray-400 font-medium">{centerLabel}</span>}
        </div>
      </div>
      <div className="flex flex-col gap-2">
        {data.map((d, i) => (
          <div key={i} className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-sm" style={{ backgroundColor: colorMap[d.color] || d.color }} />
            <span className="text-sm font-medium text-gray-600">{d.label}</span>
            <span className="text-sm font-bold text-navy-900 ml-1">{d.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
