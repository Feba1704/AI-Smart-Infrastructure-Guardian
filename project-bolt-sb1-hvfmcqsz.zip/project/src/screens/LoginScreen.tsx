import { useState } from 'react';
import { ShieldCheck, Mail, Lock, ArrowRight, Activity, Brain, TrendingUp, Wrench } from 'lucide-react';

interface LoginScreenProps {
  onLogin: () => void;
}

export default function LoginScreen({ onLogin }: LoginScreenProps) {
  const [email, setEmail] = useState('dr.rivera@structureguard.ai');
  const [password, setPassword] = useState('••••••••');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => onLogin(), 800);
  };

  return (
    <div className="min-h-screen flex">
      {/* Left panel — branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-navy-900 relative overflow-hidden flex-col justify-between p-12">
        <div className="absolute inset-0 grid-pattern opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-br from-navy-900 via-navy-800 to-navy-950 opacity-90" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-teal-500/10 blur-3xl" />

        <div className="relative z-10 flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-teal-500 flex items-center justify-center shadow-lg shadow-teal-500/30">
            <ShieldCheck className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-white font-bold text-lg leading-tight">STRUCTUREGUARD</h1>
            <p className="text-teal-400 text-xs font-semibold tracking-widest">AI MONITORING</p>
          </div>
        </div>

        <div className="relative z-10">
          <h2 className="text-4xl font-bold text-white leading-tight mb-4">
            AI-Powered<br />Infrastructure<br />Health Monitoring
          </h2>
          <p className="text-navy-200 text-base max-w-md leading-relaxed mb-8">
            Monitor bridges, buildings, and public structures with IoT sensors. Our AI learns normal behavior, detects anomalies, and predicts risks before failure.
          </p>

          <div className="flex items-center gap-3 mb-6">
            {[
              { icon: Brain, label: 'LEARN', color: 'text-teal-400' },
              { icon: Activity, label: 'DETECT', color: 'text-warning-400' },
              { icon: TrendingUp, label: 'PREDICT', color: 'text-danger-400' },
              { icon: Wrench, label: 'PREVENT', color: 'text-success-400' },
            ].map((step, i) => {
              const Icon = step.icon;
              return (
                <div key={step.label} className="flex items-center gap-3">
                  <div className="flex flex-col items-center gap-2">
                    <div className="w-10 h-10 rounded-lg bg-navy-800 border border-navy-700 flex items-center justify-center">
                      <Icon className={`w-5 h-5 ${step.color}`} />
                    </div>
                    <span className="text-[10px] font-bold text-white tracking-wider">{step.label}</span>
                  </div>
                  {i < 3 && <div className="w-6 h-px bg-navy-700 mt-[-20px]" />}
                </div>
              );
            })}
          </div>
        </div>

        <div className="relative z-10 flex items-center gap-6 text-navy-300">
          <div><span className="text-2xl font-bold text-white">10</span><span className="text-xs ml-1">Structures</span></div>
          <div className="w-px h-8 bg-navy-700" />
          <div><span className="text-2xl font-bold text-white">614</span><span className="text-xs ml-1">Sensors</span></div>
          <div className="w-px h-8 bg-navy-700" />
          <div><span className="text-2xl font-bold text-white">91.3%</span><span className="text-xs ml-1">AI Accuracy</span></div>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 flex items-center justify-center bg-gray-50 p-8">
        <div className="w-full max-w-sm animate-slide-up">
          <div className="lg:hidden flex items-center gap-3 mb-8 justify-center">
            <div className="w-12 h-12 rounded-xl bg-teal-500 flex items-center justify-center">
              <ShieldCheck className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-navy-900 font-bold text-lg">STRUCTUREGUARD</h1>
              <p className="text-teal-600 text-xs font-semibold tracking-widest">AI MONITORING</p>
            </div>
          </div>

          <h2 className="text-2xl font-bold text-navy-900 mb-1">Welcome back</h2>
          <p className="text-sm text-gray-400 mb-8">Sign in to access your monitoring dashboard</p>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="text-xs font-semibold text-navy-700 mb-1.5 block">Email Address</label>
              <div className="relative">
                <Mail className="w-4.5 h-4.5 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" style={{ width: 18, height: 18 }} />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="input-field pl-10"
                  placeholder="you@organization.com"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-navy-700">Password</label>
                <span className="text-xs text-teal-600 font-medium cursor-pointer hover:text-teal-500">Forgot?</span>
              </div>
              <div className="relative">
                <Lock className="text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" style={{ width: 18, height: 18 }} />
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="input-field pl-10"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" defaultChecked className="w-4 h-4 rounded border-gray-300 text-navy-600 focus:ring-navy-400" />
              <span className="text-xs text-gray-500">Keep me signed in for 30 days</span>
            </label>

            <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2 py-3 disabled:opacity-60">
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Authenticating...
                </span>
              ) : (
                <>
                  Sign In to Dashboard
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-gray-200">
            <p className="text-xs text-gray-400 text-center">
              Secured by 256-bit encryption · SOC 2 Type II compliant
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
