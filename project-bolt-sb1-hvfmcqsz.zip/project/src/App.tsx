import { useState } from 'react';
import type { Structure } from '@/types';
import type { PageId } from '@/types/nav';
import Sidebar from '@/components/layout/Sidebar';
import TopBar from '@/components/layout/TopBar';
import LoginScreen from '@/screens/LoginScreen';
import DashboardScreen from '@/screens/DashboardScreen';
import InfrastructureScreen from '@/screens/InfrastructureScreen';
import StructureDetailsScreen from '@/screens/StructureDetailsScreen';
import LiveMonitoringScreen from '@/screens/LiveMonitoringScreen';
import AIAnalysisScreen from '@/screens/AIAnalysisScreen';
import AlertsScreen from '@/screens/AlertsScreen';
import MaintenanceScreen from '@/screens/MaintenanceScreen';
import ReportsScreen from '@/screens/ReportsScreen';
import { structures, alerts, maintenanceItems, reports, aiPredictions } from '@/data/mockData';

function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [page, setPage] = useState<PageId>('dashboard');
  const [selectedStructure, setSelectedStructure] = useState<Structure | undefined>(structures[0]);

  const activeAlertCount = alerts.filter(a => a.status === 'active').length;

  if (!loggedIn) {
    return <LoginScreen onLogin={() => setLoggedIn(true)} />;
  }

  const handleNavigate = (p: PageId) => {
    setPage(p);
  };

  const handleSelectStructure = (s: Structure) => {
    setSelectedStructure(s);
    setPage('structure-details');
  };

  const renderPage = () => {
    switch (page) {
      case 'dashboard':
        return <DashboardScreen structures={structures} alerts={alerts} predictions={aiPredictions} onNavigate={handleNavigate} onSelectStructure={handleSelectStructure} />;
      case 'infrastructure':
        return <InfrastructureScreen structures={structures} onSelectStructure={handleSelectStructure} />;
      case 'structure-details':
        return selectedStructure
          ? <StructureDetailsScreen structure={selectedStructure} onNavigate={handleNavigate} onBack={() => setPage('infrastructure')} />
          : <InfrastructureScreen structures={structures} onSelectStructure={handleSelectStructure} />;
      case 'live-monitoring':
        return <LiveMonitoringScreen structures={structures} selectedStructure={selectedStructure} onSelectStructure={setSelectedStructure} onNavigate={handleNavigate} />;
      case 'ai-analysis':
        return <AIAnalysisScreen structures={structures} selectedStructure={selectedStructure} onSelectStructure={setSelectedStructure} onNavigate={handleNavigate} />;
      case 'alerts':
        return <AlertsScreen alerts={alerts} onNavigate={handleNavigate} />;
      case 'maintenance':
        return <MaintenanceScreen maintenanceItems={maintenanceItems} onNavigate={handleNavigate} />;
      case 'reports':
        return <ReportsScreen reports={reports} />;
      default:
        return <DashboardScreen structures={structures} alerts={alerts} predictions={aiPredictions} onNavigate={handleNavigate} onSelectStructure={handleSelectStructure} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar current={page} onNavigate={handleNavigate} />
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar current={page} alertCount={activeAlertCount} onNavigate={handleNavigate} />
        <main className="flex-1 overflow-y-auto scrollbar-thin">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}

export default App;
