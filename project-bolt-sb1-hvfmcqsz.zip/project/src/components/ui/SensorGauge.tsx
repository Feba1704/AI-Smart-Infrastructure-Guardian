interface SensorGaugeProps {
  label: string;
  value: number;
  max: number;
  unit: string;
  normalRange: [number, number];
  icon?: string;
}

export default function SensorGauge({ label, value, max, unit, normalRange, icon }: SensorGaugeProps) {
  const percent = Math.min((value / max) * 100, 100);
  const isNormal = value >= normalRange[0] && value <= normalRange[1];
  const isWarning = !isNormal && value < max * 0.85;
  const color = isNormal ? '#10b981' : isWarning ? '#f59e0b' : '#ef4444';
  const statusText = isNormal ? 'Normal' : isWarning ? 'Elevated' : 'Critical';

  const radius = 28;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percent / 100) * circumference * 0.75;

  return (
    <div className="card p-4 flex flex-col items-center">
      <div className="relative" style={{ width: 72, height: 60 }}>
        <svg width="72" height="60" viewBox="0 0 72 60">
          <path d="M 6 50 A 30 30 0 0 1 66 50" fill="none" stroke="#e2e8f0" strokeWidth="6" strokeLinecap="round" />
          <path d="M 6 50 A 30 30 0 0 1 66 50" fill="none" stroke={color} strokeWidth="6" strokeLinecap="round" strokeDasharray={circumference * 0.75} strokeDashoffset={offset} style={{ transition: 'stroke-dashoffset 1s ease-out' }} />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center" style={{ paddingTop: 8 }}>
          <span className="text-lg font-bold" style={{ color }}>{value}</span>
        </div>
      </div>
      <span className="text-xs font-semibold text-navy-900 mt-1">{label}</span>
      <span className="text-[10px] text-gray-400">{unit}</span>
      <div className="flex items-center gap-1 mt-1.5">
        <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
        <span className="text-[10px] font-medium" style={{ color }}>{statusText}</span>
      </div>
    </div>
  );
}
