import { Brain, Eye, TrendingUp, Wrench, Wifi } from 'lucide-react';

interface PipelineStep {
  icon: typeof Brain;
  label: string;
  sublabel: string;
  color: string;
  bgColor: string;
}

const steps: PipelineStep[] = [
  { icon: Wifi, label: 'IoT Data', sublabel: 'Sensors streaming', color: 'text-navy-600', bgColor: 'bg-navy-100' },
  { icon: Brain, label: 'Normal Behavior Learning', sublabel: 'AI model training', color: 'text-teal-600', bgColor: 'bg-teal-100' },
  { icon: Eye, label: 'Anomaly Detection', sublabel: 'Pattern matching', color: 'text-warning-600', bgColor: 'bg-warning-100' },
  { icon: TrendingUp, label: 'Risk Prediction', sublabel: 'Failure forecasting', color: 'text-danger-600', bgColor: 'bg-danger-100' },
  { icon: Wrench, label: 'Maintenance Recommendation', sublabel: 'Preventive action', color: 'text-success-600', bgColor: 'bg-success-100' },
];

export default function Pipeline() {
  return (
    <div className="flex items-center gap-1 overflow-x-auto pb-2 scrollbar-thin">
      {steps.map((step, i) => {
        const Icon = step.icon;
        return (
          <div key={step.label} className="flex items-center gap-1 shrink-0">
            <div className="flex flex-col items-center gap-1.5 min-w-[130px]">
              <div className={`w-12 h-12 rounded-xl ${step.bgColor} flex items-center justify-center`}>
                <Icon className={`w-6 h-6 ${step.color}`} />
              </div>
              <span className="text-xs font-semibold text-navy-900 text-center leading-tight">{step.label}</span>
              <span className="text-[10px] text-gray-400 text-center">{step.sublabel}</span>
            </div>
            {i < steps.length - 1 && (
              <div className="flex items-center h-12">
                <svg width="24" height="12" viewBox="0 0 24 12">
                  <line x1="0" y1="6" x2="20" y2="6" stroke="#cbd5e1" strokeWidth="2" strokeDasharray="3 2" />
                  <polygon points="20,2 24,6 20,10" fill="#cbd5e1" />
                </svg>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
