interface BarChartProps {
  data: { label: string; value: number; color?: string }[];
  height?: number;
  showValues?: boolean;
  unit?: string;
}

export default function BarChart({ data, height = 180, showValues = true, unit = '' }: BarChartProps) {
  const maxVal = Math.max(...data.map(d => d.value)) * 1.2 || 1;
  const barWidth = 100 / data.length;

  return (
    <div className="w-full">
      <div className="flex items-end gap-2" style={{ height }}>
        {data.map((d, i) => (
          <div key={i} className="flex-1 flex flex-col items-center justify-end h-full">
            <div className="w-full flex flex-col items-center justify-end h-full">
              {showValues && (
                <span className="text-xs font-semibold text-gray-700 mb-1">{d.value}{unit}</span>
              )}
              <div
                className="w-full rounded-t-md transition-all duration-700 ease-out"
                style={{
                  height: `${(d.value / maxVal) * 100}%`,
                  backgroundColor: d.color || '#3a5a9e',
                  minHeight: 4,
                }}
              />
            </div>
          </div>
        ))}
      </div>
      <div className="flex gap-2 mt-2">
        {data.map((d, i) => (
          <div key={i} className="flex-1 text-center">
            <span className="text-xs text-gray-500 font-medium truncate block">{d.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
