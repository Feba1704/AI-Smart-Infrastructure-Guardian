import { LayoutDashboard, Building2, Radio, Brain, Bell, Wrench, FileBarChart, ShieldCheck } from 'lucide-react';
import type { PageId } from '@/types/nav';

interface SidebarProps {
  current: PageId;
  onNavigate: (page: PageId) => void;
  collapsed?: boolean;
}

const navItems: { id: PageId; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'infrastructure', label: 'Infrastructure', icon: Building2 },
  { id: 'live-monitoring', label: 'Live Monitoring', icon: Radio },
  { id: 'ai-analysis', label: 'AI Analysis', icon: Brain },
  { id: 'alerts', label: 'Alerts', icon: Bell },
  { id: 'maintenance', label: 'Predictive Maintenance', icon: Wrench },
  { id: 'reports', label: 'Reports', icon: FileBarChart },
];

export default function Sidebar({ current, onNavigate }: SidebarProps) {
  return (
    <aside className="w-60 bg-navy-900 flex flex-col h-screen sticky top-0 shrink-0">
      {/* Logo */}
      <div className="px-5 py-5 flex items-center gap-3 border-b border-navy-800">
        <div className="w-10 h-10 rounded-xl bg-teal-500 flex items-center justify-center shadow-lg shadow-teal-500/20">
          <ShieldCheck className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-white font-bold text-sm leading-tight">STRUCTUREGUARD</h1>
          <p className="text-teal-400 text-[10px] font-semibold tracking-widest">AI MONITORING</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto scrollbar-thin">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = current === item.id || (item.id === 'infrastructure' && current === 'structure-details');
          return (
            <div
              key={item.id}
              className={`nav-item ${isActive ? 'nav-item-active' : 'nav-item-inactive'}`}
              onClick={() => onNavigate(item.id)}
            >
              <Icon className="w-[18px] h-[18px] shrink-0" />
              <span className="truncate">{item.label}</span>
            </div>
          );
        })}
      </nav>

      {/* Pipeline badge */}
      <div className="px-3 pb-4">
        <div className="rounded-xl bg-navy-800 border border-navy-700 p-3">
          <p className="text-[10px] font-bold text-teal-400 tracking-widest mb-2">CORE INNOVATION</p>
          <div className="space-y-1">
            {['LEARN', 'DETECT', 'PREDICT', 'PREVENT'].map((word, i) => (
              <div key={word} className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-navy-300">{String(i + 1)}</span>
                <span className="text-[11px] font-semibold text-white">{word}</span>
                {i < 3 && <div className="w-3 h-px bg-navy-600 ml-auto" />}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* User */}
      <div className="px-3 pb-4 pt-2 border-t border-navy-800">
        <div className="flex items-center gap-3 px-2">
          <div className="w-9 h-9 rounded-full bg-teal-600 flex items-center justify-center text-white text-sm font-bold">DR</div>
          <div className="min-w-0">
            <p className="text-white text-xs font-semibold truncate">Dr. Rivera</p>
            <p className="text-navy-300 text-[10px] truncate">Structural Engineer</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
