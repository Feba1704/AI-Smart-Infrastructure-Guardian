import { useState } from 'react';
import { Brain, Wifi, Eye, TrendingUp, Wrench, AlertTriangle, CheckCircle2, ArrowRight, Cpu, Activity, Sparkles, ChevronRight } from 'lucide-react';
import type { Structure } from '@/types';
import type { PageId } from '@/types/nav';
import Pipeline from '@/components/ui/Pipeline';
import LineChart from '@/components/ui/LineChart';
import ProgressRing from '@/components/ui/ProgressRing';
import RiskBadge from '@/components/ui/Badge';

interface AIAnalysisScreenProps {
  structures: Structure[];
  selectedStructure?: Structure;
  onSelectStructure: (s: Structure) => void;
  onNavigate: (page: PageId) => void;
}

export default function AIAnalysisScreen({ structures, selectedStructure, onSelectStructure, onNavigate }: AIAnalysisScreenProps) {
  const s = selectedStructure || structures[0];
  const [activeStep, setActiveStep] = useState(0);

  const steps = [
    { icon: Wifi, label: 'IoT Data', desc: '614 sensors across 10 structures streaming vibration, strain, movement, temperature & load data at 10Hz', color: 'navy' },
    { icon: Brain, label: 'Normal Behavior Learning', desc: 'Deep learning model trained on 90 days of baseline data per structure. Learns seasonal patterns, traffic cycles & thermal expansion.', color: 'teal' },
    { icon: Eye, label: 'Anomaly Detection', desc: 'Real-time comparison of current readings against learned model. Deviation >10% triggers anomaly flag.', color: 'warning' },
    { icon: TrendingUp, label: 'Risk Prediction', desc: 'Time-series forecasting predicts failure probability within configurable prediction windows (7-300 days).', color: 'danger' },
    { icon: Wrench, label: 'Maintenance Recommendation', desc: 'AI generates prioritized maintenance actions with cost estimates, urgency levels & inspection details.', color: 'success' },
  ];

  const colorClasses: Record<string, { bg: string; text: string; border: string }> = {
    navy: { bg: 'bg-navy-100', text: 'text-navy-600', border: 'border-navy-200' },
    teal: { bg: 'bg-teal-100', text: 'text-teal-600', border: 'border-teal-200' },
    warning: { bg: 'bg-warning-100', text: 'text-warning-600', border: 'border-warning-200' },
    danger: { bg: 'bg-danger-100', text: 'text-danger-600', border: 'border-danger-200' },
    success: { bg: 'bg-success-100', text: 'text-success-600', border: 'border-success-200' },
  };

  return (
    <div className="p-6 space-y-5 animate-fade-in">
      {/* Structure selector */}
      <div className="card p-4">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-teal-600" />
            <span className="text-sm font-semibold text-navy-900">AI Analysis for:</span>
          </div>
          <select
            value={s.id}
            onChange={e => { const found = structures.find(x => x.id === e.target.value); if (found) onSelectStructure(found); }}
            className="bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm text-navy-900 focus:outline-none focus:ring-2 focus:ring-navy-400"
          >
            {structures.map(st => <option key={st.id} value={st.id}>{st.name} — {st.location}</option>)}
          </select>
          <RiskBadge level={s.riskLevel} />
          <div className="ml-auto flex items-center gap-2 px-3 py-1.5 rounded-lg bg-teal-50 border border-teal-100">
            <Sparkles className="w-4 h-4 text-teal-600" />
            <span className="text-xs font-semibold text-teal-700">Model v3.2 · 91.3% accuracy</span>
          </div>
        </div>
      </div>

      {/* Pipeline visualization */}
      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="section-title">AI Analysis Pipeline</h3>
          <span className="text-xs font-semibold text-teal-600">LEARN → DETECT → PREDICT → PREVENT</span>
        </div>
        <Pipeline />
      </div>

      {/* Pipeline steps detail */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-3">
        {steps.map((step, i) => {
          const Icon = step.icon;
          const c = colorClasses[step.color];
          const isActive = activeStep === i;
          return (
            <div
              key={i}
              onClick={() => setActiveStep(i)}
              className={`card p-4 cursor-pointer transition-all ${isActive ? `border-2 ${c.border} shadow-md` : 'hover:shadow-md'}`}
            >
              <div className={`w-10 h-10 rounded-xl ${c.bg} flex items-center justify-center mb-3`}>
                <Icon className={`w-5 h-5 ${c.text}`} />
              </div>
              <span className="text-[10px] font-bold text-gray-400">STEP {i + 1}</span>
              <h4 className="text-sm font-bold text-navy-900 mt-0.5">{step.label}</h4>
              <p className="text-xs text-gray-500 mt-1 leading-relaxed">{step.desc}</p>
            </div>
          );
        })}
      </div>

      {/* Key metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-5">
        <div className="card p-5 flex flex-col items-center">
          <h4 className="section-title mb-4">Anomaly Score</h4>
          <ProgressRing value={s.anomalyScore} size={100} stroke={7} color="#ef4444" label="0-100" />
          <p className="text-xs text-gray-500 mt-3 text-center">{s.anomalyScore > 70 ? 'High anomaly detected' : s.anomalyScore > 40 ? 'Moderate anomaly' : 'Low anomaly'}</p>
        </div>

        <div className="card p-5 flex flex-col items-center">
          <h4 className="section-title mb-4">Deviation</h4>
          <ProgressRing value={Math.round(s.deviationPercent)} size={100} stroke={7} color="#f59e0b" label="from normal" />
          <p className="text-xs text-gray-500 mt-3 text-center">{s.deviationPercent > 20 ? 'Significant deviation' : 'Minor deviation'}</p>
        </div>

        <div className="card p-5 flex flex-col items-center">
          <h4 className="section-title mb-4">Risk Probability</h4>
          <ProgressRing value={s.riskProbability} size={100} stroke={7} color="#dc2626" label="failure chance" />
          <p className="text-xs text-gray-500 mt-3 text-center">{s.riskProbability > 70 ? 'High risk — act now' : s.riskProbability > 40 ? 'Moderate risk' : 'Low risk'}</p>
        </div>

        <div className="card p-5 flex flex-col items-center justify-center">
          <h4 className="section-title mb-4">Prediction Window</h4>
          <div className="w-20 h-20 rounded-xl bg-navy-100 flex items-center justify-center mb-2">
            <span className="text-2xl font-bold text-navy-700">{s.predictionWindow.split(' ')[0]}</span>
          </div>
          <span className="text-xs font-semibold text-navy-900">{s.predictionWindow.split(' ').slice(1).join(' ')}</span>
          <p className="text-xs text-gray-400 mt-1">estimated time to failure</p>
        </div>
      </div>

      {/* Anomaly detection chart */}
      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Eye className="w-4.5 h-4.5 text-warning-600" style={{ width: 18, height: 18 }} />
            <h3 className="section-title">Anomaly Detection — Vibration Sensor</h3>
          </div>
          <RiskBadge level={s.riskLevel} />
        </div>
        <LineChart
          labels={s.learnedNormal.map(t => t.timestamp)}
          series={[
            { name: 'Learned Normal', data: s.learnedNormal.map(t => t.vibration), color: '#94a3b8', dashed: true },
            { name: 'Current Reading', data: s.currentBehavior.map(t => t.vibration), color: '#3a5a9e' },
          ]}
          height={240}
          showLegend
          showArea
        />
        <div className="mt-3 p-3 rounded-lg bg-danger-50 border border-danger-100 flex items-start gap-2">
          <AlertTriangle className="w-4.5 h-4.5 text-danger-500 mt-0.5 shrink-0" style={{ width: 18, height: 18 }} />
          <div>
            <p className="text-sm font-semibold text-danger-700">Anomaly Detected</p>
            <p className="text-xs text-danger-600 mt-0.5">Current vibration readings deviate {s.deviationPercent}% from the learned normal baseline. Pattern matches fatigue-induced oscillation profile.</p>
          </div>
        </div>
      </div>

      {/* AI Explanation */}
      <div className="card p-5 bg-gradient-to-br from-navy-900 to-navy-800 border-navy-800">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-teal-500 flex items-center justify-center shrink-0">
            <Cpu className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h4 className="text-sm font-bold text-white">AI Explanation</h4>
              <span className="badge-info text-[10px]">Plain English</span>
            </div>
            <p className="text-sm text-navy-100 leading-relaxed">{s.aiSummary}</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
              <div className="bg-navy-800/50 rounded-lg p-3 border border-navy-700">
                <p className="text-[10px] text-teal-400 font-semibold uppercase">Model</p>
                <p className="text-sm text-white font-semibold">LSTM Neural Net</p>
              </div>
              <div className="bg-navy-800/50 rounded-lg p-3 border border-navy-700">
                <p className="text-[10px] text-teal-400 font-semibold uppercase">Training Data</p>
                <p className="text-sm text-white font-semibold">90 days · 2.3M points</p>
              </div>
              <div className="bg-navy-800/50 rounded-lg p-3 border border-navy-700">
                <p className="text-[10px] text-teal-400 font-semibold uppercase">Confidence</p>
                <p className="text-sm text-white font-semibold">{100 - s.anomalyScore > 50 ? 'High (92%)' : 'Moderate (78%)'}</p>
              </div>
              <div className="bg-navy-800/50 rounded-lg p-3 border border-navy-700">
                <p className="text-[10px] text-teal-400 font-semibold uppercase">Last Updated</p>
                <p className="text-sm text-white font-semibold">2 hours ago</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Maintenance recommendation */}
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-4">
          <Wrench className="w-4.5 h-4.5 text-success-600" style={{ width: 18, height: 18 }} />
          <h3 className="section-title">Maintenance Recommendation</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-lg bg-gray-50 border border-gray-100">
            <p className="text-xs font-semibold text-gray-400 uppercase">Recommended Action</p>
            <p className="text-sm font-semibold text-navy-900 mt-1">
              {s.riskLevel === 'critical' ? 'Emergency structural inspection' : s.riskLevel === 'warning' ? 'Schedule detailed inspection' : 'Continue routine monitoring'}
            </p>
          </div>
          <div className="p-4 rounded-lg bg-gray-50 border border-gray-100">
            <p className="text-xs font-semibold text-gray-400 uppercase">Urgency</p>
            <p className="text-sm font-semibold mt-1" style={{ color: s.riskLevel === 'critical' ? '#ef4444' : s.riskLevel === 'warning' ? '#f59e0b' : '#10b981' }}>
              {s.riskLevel === 'critical' ? 'Immediate — within ' + s.predictionWindow : s.riskLevel === 'warning' ? 'Within ' + s.predictionWindow : 'Routine schedule'}
            </p>
          </div>
          <div className="p-4 rounded-lg bg-gray-50 border border-gray-100">
            <p className="text-xs font-semibold text-gray-400 uppercase">Priority</p>
            <p className="text-sm font-semibold mt-1" style={{ color: s.riskLevel === 'critical' ? '#ef4444' : s.riskLevel === 'warning' ? '#f59e0b' : '#10b981' }}>
              {s.riskLevel === 'critical' ? 'Urgent' : s.riskLevel === 'warning' ? 'High' : 'Low'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3 mt-4">
          <button onClick={() => onNavigate('maintenance')} className="btn-teal flex items-center gap-2">
            <Wrench className="w-4 h-4" /> View Maintenance Plan
          </button>
          <button onClick={() => onNavigate('alerts')} className="btn-secondary flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" /> View Related Alerts
          </button>
        </div>
      </div>
    </div>
  );
}
