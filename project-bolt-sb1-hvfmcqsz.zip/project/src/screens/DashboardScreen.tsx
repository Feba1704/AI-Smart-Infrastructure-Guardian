import { Building2, ShieldCheck, AlertTriangle, Activity, Cpu, TrendingUp, ArrowRight, Radio, Thermometer, Gauge, Waves, Weight } from 'lucide-react';
import type { Structure, Alert, AIPrediction } from '@/types';
import type { PageId } from '@/types/nav';
import StatCard from '@/components/ui/StatCard';
import HealthGauge from '@/components/ui/HealthGauge';
import DonutChart from '@/components/ui/DonutChart';
import LineChart from '@/components/ui/LineChart';
import InfrastructureMap from '@/components/ui/InfrastructureMap';
import RiskBadge from '@/components/ui/Badge';
import Sparkline from '@/components/ui/Sparkline';
import { portfolioHealthTrend, riskDistribution, sensorTypeBreakdown } from '@/data/mockData';

interface DashboardScreenProps {
  structures: Structure[];
  alerts: Alert[];
  predictions: AIPrediction[];
  onNavigate: (page: PageId) => void;
  onSelectStructure: (s: Structure) => void;
}

export default function DashboardScreen({ structures, alerts, predictions, onNavigate, onSelectStructure }: DashboardScreenProps) {
  const total = structures.length;
  const healthy = structures.filter(s => s.riskLevel === 'healthy').length;
  const warning = structures.filter(s => s.riskLevel === 'warning').length;
  const critical = structures.filter(s => s.riskLevel === 'critical').length;
  const avgScore = Math.round(structures.reduce((sum, s) => sum + s.healthScore, 0) / total);
  const totalSensors = structures.reduce((sum, s) => sum + s.sensorCount, 0);
  const activeSensors = structures.reduce((sum, s) => sum + s.activeSensors, 0);
  const activeAlerts = alerts.filter(a => a.status === 'active').length;

  const recentAlerts = alerts.slice(0, 4);

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        <StatCard icon={Building2} label="Total Structures" value={total} sublabel="Active monitoring" color="navy" />
        <StatCard icon={ShieldCheck} label="Healthy" value={healthy} sublabel={`${Math.round(healthy/total*100)}% of portfolio`} color="success" />
        <StatCard icon={AlertTriangle} label="Warning" value={warning} sublabel="Needs attention" color="warning" />
        <StatCard icon={AlertTriangle} label="Critical" value={critical} sublabel="Immediate action" color="danger" />
        <StatCard icon={Radio} label="Sensors Online" value={`${activeSensors}/${totalSensors}`} sublabel={`${Math.round(activeSensors/totalSensors*100)}% operational`} color="teal" />
      </div>

      {/* Main grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Health Score + Risk Distribution */}
        <div className="card p-5">
          <h3 className="section-title mb-4">Portfolio Health Score</h3>
          <div className="flex items-center justify-around">
            <HealthGauge score={avgScore} size={140} />
            <div className="space-y-3">
              <DonutChart
                data={riskDistribution.map(d => ({ ...d, color: d.color }))}
                size={120}
                thickness={18}
                centerValue={total}
                centerLabel="Total"
              />
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-gray-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-gray-500">30-Day Trend</span>
              <span className="text-xs font-semibold text-danger-600">↓ 5 pts</span>
            </div>
            <Sparkline data={portfolioHealthTrend.map(d => d.score)} color="#3a5a9e" width={280} height={36} />
          </div>
        </div>

        {/* Risk Trend Chart */}
        <div className="card p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="section-title">Risk Distribution Over Time</h3>
            <div className="flex gap-2">
              <button className="text-xs font-semibold text-navy-700 bg-navy-100 px-3 py-1 rounded-md">30D</button>
              <button className="text-xs font-semibold text-gray-400 px-3 py-1 rounded-md hover:bg-gray-100">90D</button>
              <button className="text-xs font-semibold text-gray-400 px-3 py-1 rounded-md hover:bg-gray-100">1Y</button>
            </div>
          </div>
          <LineChart
            labels={portfolioHealthTrend.map(d => d.label)}
            series={[
              { name: 'Portfolio Health Score', data: portfolioHealthTrend.map(d => d.score), color: '#3a5a9e' },
              { name: 'Anomaly Count', data: [8, 12, 10, 14, 11, 9, 13], color: '#f59e0b' },
            ]}
            height={200}
            showArea
          />
        </div>
      </div>

      {/* Map + Sensor Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="section-title">Infrastructure Map</h3>
            <button onClick={() => onNavigate('infrastructure')} className="text-xs font-semibold text-teal-600 hover:text-teal-500 flex items-center gap-1">
              View All <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <InfrastructureMap structures={structures} onSelectStructure={onSelectStructure} height={300} />
        </div>

        <div className="card p-5">
          <h3 className="section-title mb-4">Sensor Status</h3>
          <div className="space-y-3">
            {sensorTypeBreakdown.map(sensor => {
              const pct = Math.round((sensor.online / sensor.total) * 100);
              const Icon = sensor.type === 'Vibration' ? Waves : sensor.type === 'Strain' ? Gauge : sensor.type === 'Movement' ? Activity : sensor.type === 'Temperature' ? Thermometer : Weight;
              return (
                <div key={sensor.type} className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-gray-50 border border-gray-200 flex items-center justify-center shrink-0">
                    <Icon className="w-4.5 h-4.5 text-navy-500" style={{ width: 18, height: 18 }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-semibold text-navy-900">{sensor.type}</span>
                      <span className="text-xs font-medium text-gray-500">{sensor.online}/{sensor.total}</span>
                    </div>
                    <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-700 ${pct === 100 ? 'bg-success-500' : pct >= 95 ? 'bg-teal-500' : 'bg-warning-500'}`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-4 pt-4 border-t border-gray-100 flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500">Total Operational</span>
            <span className="text-lg font-bold text-teal-600">{Math.round(activeSensors/totalSensors*100)}%</span>
          </div>
        </div>
      </div>

      {/* Alerts + AI Predictions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Alerts */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="section-title">Recent Alerts</h3>
            <button onClick={() => onNavigate('alerts')} className="text-xs font-semibold text-teal-600 hover:text-teal-500 flex items-center gap-1">
              View All <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="space-y-3">
            {recentAlerts.map(alert => (
              <div
                key={alert.id}
                className="flex items-start gap-3 p-3 rounded-lg border border-gray-100 hover:border-gray-200 hover:bg-gray-50 transition-all cursor-pointer"
                onClick={() => onNavigate('alerts')}
              >
                <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${alert.severity === 'critical' ? 'bg-danger-500' : alert.severity === 'warning' ? 'bg-warning-500' : 'bg-success-500'}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-sm font-semibold text-navy-900 truncate">{alert.structureName}</span>
                    <RiskBadge level={alert.severity} />
                  </div>
                  <p className="text-xs text-gray-500 truncate">{alert.issue}</p>
                  <p className="text-[10px] text-gray-400 mt-0.5">{alert.timestamp} · {alert.confidence}% confidence</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Predictions */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-teal-600" />
              <h3 className="section-title">AI Predictions</h3>
            </div>
            <button onClick={() => onNavigate('ai-analysis')} className="text-xs font-semibold text-teal-600 hover:text-teal-500 flex items-center gap-1">
              Analysis <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="space-y-3">
            {predictions.slice(0, 4).map(pred => (
              <div
                key={pred.id}
                className="flex items-start gap-3 p-3 rounded-lg border border-gray-100 hover:border-gray-200 hover:bg-gray-50 transition-all cursor-pointer"
                onClick={() => onNavigate('ai-analysis')}
              >
                <div className="w-10 h-10 rounded-lg bg-teal-50 border border-teal-100 flex items-center justify-center shrink-0">
                  <TrendingUp className="w-5 h-5 text-teal-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-sm font-semibold text-navy-900 truncate">{pred.structureName}</span>
                    <span className={`text-xs font-bold ${pred.probability >= 70 ? 'text-danger-600' : pred.probability >= 40 ? 'text-warning-600' : 'text-teal-600'}`}>
                      {pred.probability}%
                    </span>
                  </div>
                  <p className="text-xs text-gray-500">{pred.prediction}</p>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-[10px] text-gray-400">Window: {pred.window}</span>
                    <span className="text-[10px] text-gray-400">Confidence: {pred.confidence}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Innovation banner */}
      <div className="card p-5 bg-gradient-to-r from-navy-900 to-navy-800 border-navy-800">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <p className="text-xs font-bold text-teal-400 tracking-widest mb-1">CORE INNOVATION</p>
            <h3 className="text-lg font-bold text-white">LEARN → DETECT → PREDICT → PREVENT</h3>
            <p className="text-sm text-navy-200 mt-1">AI continuously learns each structure's normal behavior to detect anomalies and predict failures before they happen.</p>
          </div>
          <button onClick={() => onNavigate('ai-analysis')} className="btn-teal flex items-center gap-2">
            View AI Pipeline <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
