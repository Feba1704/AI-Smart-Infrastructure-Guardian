import { useState } from 'react';
import { FileBarChart, TrendingUp, AlertTriangle, Brain, Wrench, Download, Calendar, ChevronRight, FileText } from 'lucide-react';
import type { ReportItem } from '@/types';
import LineChart from '@/components/ui/LineChart';
import BarChart from '@/components/ui/BarChart';
import DonutChart from '@/components/ui/DonutChart';
import { portfolioHealthTrend } from '@/data/mockData';

interface ReportsScreenProps {
  reports: ReportItem[];
}

const typeConfig = {
  'health-trend': { label: 'Health Trend', icon: TrendingUp, color: 'bg-navy-100 text-navy-600' },
  anomaly: { label: 'Anomaly', icon: AlertTriangle, color: 'bg-warning-100 text-warning-600' },
  prediction: { label: 'Prediction', icon: Brain, color: 'bg-teal-100 text-teal-600' },
  'maintenance-history': { label: 'Maintenance', icon: Wrench, color: 'bg-success-100 text-success-600' },
};

const statusConfig = {
  generated: { label: 'Generated', classes: 'bg-success-100 text-success-700' },
  scheduled: { label: 'Scheduled', classes: 'bg-warning-100 text-warning-700' },
  archived: { label: 'Archived', classes: 'bg-gray-100 text-gray-600' },
};

export default function ReportsScreen({ reports }: ReportsScreenProps) {
  const [filter, setFilter] = useState<'all' | 'health-trend' | 'anomaly' | 'prediction' | 'maintenance-history'>('all');

  const filtered = filter === 'all' ? reports : reports.filter(r => r.type === filter);

  // Chart data
  const anomalyHistory = [
    { label: 'Jul W1', value: 5 },
    { label: 'Jul W2', value: 8 },
    { label: 'Jul W3', value: 6 },
    { label: 'Jul W4', value: 10 },
    { label: 'Aug W1', value: 8 },
    { label: 'Aug W2', value: 12 },
    { label: 'Aug W3', value: 10 },
    { label: 'Aug W4', value: 14 },
    { label: 'Sep W1', value: 11 },
    { label: 'Sep W2', value: 9 },
    { label: 'Sep W3', value: 13 },
  ];

  const maintenanceHistory = [
    { label: 'Q1', value: 4, color: '#3a5a9e' },
    { label: 'Q2', value: 7, color: '#1f9d92' },
    { label: 'Q3', value: 12, color: '#f59e0b' },
    { label: 'Q4', value: 6, color: '#ef4444' },
  ];

  const maintenanceBreakdown = [
    { label: 'Completed', value: 12, color: 'success' },
    { label: 'In Progress', value: 4, color: 'warning' },
    { label: 'Scheduled', value: 6, color: 'teal' },
  ];

  return (
    <div className="p-6 space-y-5 animate-fade-in">
      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="card p-5">
          <h3 className="section-title mb-4">Portfolio Health Trend</h3>
          <LineChart
            labels={portfolioHealthTrend.map(d => d.label)}
            series={[{ name: 'Health Score', data: portfolioHealthTrend.map(d => d.score), color: '#3a5a9e' }]}
            height={200}
            showLegend={false}
            showArea
          />
        </div>

        <div className="card p-5">
          <h3 className="section-title mb-4">Anomaly Detection History</h3>
          <BarChart
            data={anomalyHistory.map(d => ({ label: d.label, value: d.value, color: '#f59e0b' }))}
            height={200}
            showValues={false}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="card p-5">
          <h3 className="section-title mb-4">Maintenance Breakdown</h3>
          <DonutChart
            data={maintenanceBreakdown}
            size={140}
            thickness={20}
            centerValue={22}
            centerLabel="Total"
          />
        </div>

        <div className="card p-5">
          <h3 className="section-title mb-4">Maintenance by Quarter</h3>
          <BarChart data={maintenanceHistory} height={160} showValues />
        </div>

        <div className="card p-5">
          <h3 className="section-title mb-4">AI Model Performance</h3>
          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-gray-600">Accuracy</span>
                <span className="text-sm font-bold text-success-600">91.3%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full rounded-full bg-success-500" style={{ width: '91.3%' }} />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-gray-600">False Positive Rate</span>
                <span className="text-sm font-bold text-teal-600">4.2%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full rounded-full bg-teal-500" style={{ width: '4.2%' }} />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-gray-600">Mean Detection Time</span>
                <span className="text-sm font-bold text-navy-700">2.3 days</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full rounded-full bg-navy-500" style={{ width: '23%' }} />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-gray-600">Anomalies Detected</span>
                <span className="text-sm font-bold text-navy-700">847</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full rounded-full bg-navy-500" style={{ width: '85%' }} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter */}
      <div className="flex items-center gap-2 flex-wrap">
        {(['all', 'health-trend', 'anomaly', 'prediction', 'maintenance-history'] as const).map(t => (
          <button
            key={t}
            onClick={() => setFilter(t)}
            className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all ${filter === t ? 'bg-navy-700 text-white' : 'bg-white border border-gray-200 text-gray-500 hover:bg-gray-50'}`}
          >
            {t === 'all' ? 'All Reports' : typeConfig[t].label}
          </button>
        ))}
      </div>

      {/* Reports list */}
      <div className="space-y-3">
        {filtered.map(report => {
          const tc = typeConfig[report.type];
          const Icon = tc.icon;
          const sc = statusConfig[report.status];
          return (
            <div key={report.id} className="card-hover p-4 cursor-pointer animate-slide-up">
              <div className="flex items-start gap-4">
                <div className={`w-11 h-11 rounded-xl ${tc.color} flex items-center justify-center shrink-0`}>
                  <Icon className="w-5.5 h-5.5" style={{ width: 22, height: 22 }} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <h3 className="text-sm font-bold text-navy-900">{report.title}</h3>
                    <span className={`badge ${sc.classes}`}>{sc.label}</span>
                  </div>
                  <p className="text-xs text-gray-500 mb-2">{report.summary}</p>
                  <div className="flex items-center gap-4 flex-wrap">
                    <span className="text-xs text-gray-400 flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{report.date}</span>
                    <span className="text-xs text-gray-400 flex items-center gap-1"><FileText className="w-3.5 h-3.5" />{report.dataPoints.toLocaleString()} data points</span>
                    <span className="text-xs text-gray-400">{report.structureName}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {report.status === 'generated' && (
                    <button className="btn-secondary text-xs px-3 py-1.5 flex items-center gap-1">
                      <Download className="w-3.5 h-3.5" /> Download
                    </button>
                  )}
                  <ChevronRight className="w-4 h-4 text-gray-300" />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
