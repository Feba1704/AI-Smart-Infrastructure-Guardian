interface SparklineProps {
  data: number[];
  color: string;
  height?: number;
  width?: number;
  showArea?: boolean;
  strokeWidth?: number;
}

export default function Sparkline({ data, color, height = 40, width = 120, showArea = true, strokeWidth = 1.5 }: SparklineProps) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const step = width / Math.max(data.length - 1, 1);

  const points = data.map((v, i) => `${i * step},${height - ((v - min) / range) * (height - 4) - 2}`);
  const path = `M ${points.join(' L ')}`;
  const areaPath = `${path} L ${width} ${height} L 0 ${height} Z`;

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible">
      {showArea && <path d={areaPath} fill={color} opacity={0.1} />}
      <path d={path} fill="none" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={width} cy={height - ((data[data.length - 1] - min) / range) * (height - 4) - 2} r={2.5} fill={color} />
    </svg>
  );
}
