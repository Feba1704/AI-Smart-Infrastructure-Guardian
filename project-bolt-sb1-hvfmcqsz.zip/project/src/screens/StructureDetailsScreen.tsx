import { ArrowLeft, MapPin, Calendar, Cpu, Radio, Activity, TrendingUp, AlertTriangle, Brain, ChevronRight, Waves, Gauge, Thermometer, Weight, Building2 } from 'lucide-react';
import type { Structure } from '@/types';
import type { PageId } from '@/types/nav';
import HealthGauge from '@/components/ui/HealthGauge';
import RiskBadge from '@/components/ui/Badge';
import LineChart from '@/components/ui/LineChart';
import SensorGauge from '@/components/ui/SensorGauge';
import ProgressRing from '@/components/ui/ProgressRing';
import Sparkline from '@/components/ui/Sparkline';

interface StructureDetailsScreenProps {
  structure: Structure;
  onNavigate: (page: PageId) => void;
  onBack: () => void;
}

const sensorConfig = [
  { key: 'vibration' as const, label: 'Vibration', unit: 'mm/s', max: 6, normal: [0.5, 2.5] as [number, number], icon: Waves },
  { key: 'strain' as const, label: 'Strain', unit: 'µε', max: 100, normal: [10, 50] as [number, number], icon: Gauge },
  { key: 'movement' as const, label: 'Movement', unit: 'mm', max: 6, normal: [0.2, 2] as [number, number], icon: Activity },
  { key: 'temperature' as const, label: 'Temperature', unit: '°C', max: 50, normal: [15, 30] as [number, number], icon: Thermometer },
  { key: 'load' as const, label: 'Load', unit: '%', max: 100, normal: [20, 70] as [number, number], icon: Weight },
];

export default function StructureDetailsScreen({ structure: s, onNavigate, onBack }: StructureDetailsScreenProps) {
  return (
    <div className="p-6 space-y-5 animate-fade-in">
      {/* Back + header */}
      <button onClick={onBack} className="flex items-center gap-2 text-sm text-gray-500 hover:text-navy-700 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Infrastructure
      </button>

      <div className="card p-5">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-navy-100 flex items-center justify-center">
              <Building2 className="w-7 h-7 text-navy-600" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-navy-900">{s.name}</h2>
              <div className="flex items-center gap-3 mt-1">
                <span className="text-sm text-gray-500 flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{s.location}</span>
                <span className="text-xs text-gray-400">·</span>
                <span className="text-xs font-semibold text-gray-600">{s.type.charAt(0).toUpperCase() + s.type.slice(1)}</span>
                <span className="text-xs text-gray-400">·</span>
                <span className="text-xs text-gray-500">ID: {s.id}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <RiskBadge level={s.riskLevel} size="md" />
            <button onClick={() => onNavigate('live-monitoring')} className="btn-secondary flex items-center gap-2">
              <Radio className="w-4 h-4" /> Live Monitor
            </button>
            <button onClick={() => onNavigate('ai-analysis')} className="btn-teal flex items-center gap-2">
              <Brain className="w-4 h-4" /> AI Analysis
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-5 pt-5 border-t border-gray-100">
          <div><p className="metric-label">Built</p><p className="text-sm font-bold text-navy-900">{s.builtYear}</p></div>
          <div><p className="metric-label">Last Inspection</p><p className="text-sm font-bold text-navy-900">{s.lastInspection}</p></div>
          <div><p className="metric-label">Sensors</p><p className="text-sm font-bold text-navy-900">{s.activeSensors}/{s.sensorCount} active</p></div>
          <div><p className="metric-label">Status</p><p className="text-sm font-bold text-teal-600 capitalize">{s.sensorStatus}</p></div>
        </div>
      </div>

      {/* Health Score + Risk metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="card p-5 flex flex-col items-center justify-center">
          <HealthGauge score={s.healthScore} size={160} />
        </div>

        <div className="card p-5 lg:col-span-2">
          <h3 className="section-title mb-4">AI Risk Assessment</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <ProgressRing value={s.anomalyScore} size={80} color="#ef4444" label="Anomaly Score" sublabel="0-100" />
            <ProgressRing value={Math.round(s.deviationPercent)} size={80} color="#f59e0b" label="Deviation" sublabel="from normal" />
            <ProgressRing value={s.riskProbability} size={80} color="#dc2626" label="Risk Probability" sublabel="failure chance" />
            <div className="flex flex-col items-center justify-center text-center">
              <div className="w-16 h-16 rounded-xl bg-navy-100 flex items-center justify-center mb-1">
                <Calendar className="w-7 h-7 text-navy-600" />
              </div>
              <span className="text-xs font-semibold text-navy-900">{s.predictionWindow}</span>
              <span className="text-[10px] text-gray-400">prediction window</span>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-gray-100">
            <div className="flex items-start gap-2">
              <Brain className="w-4.5 h-4.5 text-teal-600 mt-0.5 shrink-0" style={{ width: 18, height: 18 }} />
              <p className="text-sm text-gray-600 leading-relaxed">{s.aiSummary}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Sensor readings */}
      <div className="card p-5">
        <h3 className="section-title mb-4">Live Sensor Readings</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {sensorConfig.map(cfg => {
            const value = s.readings[cfg.key];
            return <SensorGauge key={cfg.key} label={cfg.label} value={value} max={cfg.max} unit={cfg.unit} normalRange={cfg.normal} />;
          })}
        </div>
      </div>

      {/* Sensor trends */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {sensorConfig.slice(0, 4).map(cfg => {
          const Icon = cfg.icon;
          const data = s.trend.map(t => t[cfg.key]);
          const color = data[data.length - 1] > cfg.normal[1] ? '#ef4444' : data[data.length - 1] < cfg.normal[0] ? '#f59e0b' : '#10b981';
          return (
            <div key={cfg.key} className="card p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Icon className="w-4.5 h-4.5 text-navy-500" style={{ width: 18, height: 18 }} />
                  <h4 className="text-sm font-bold text-navy-900">{cfg.label} Trend</h4>
                </div>
                <span className="text-xs font-semibold" style={{ color }}>
                  {s.readings[cfg.key]} {cfg.unit}
                </span>
              </div>
              <LineChart
                labels={s.trend.map(t => t.timestamp)}
                series={[{ name: cfg.label, data, color }]}
                height={160}
                showLegend={false}
                showArea
                unit={cfg.unit === '°C' ? '°' : ''}
              />
            </div>
          );
        })}
      </div>

      {/* Quick links */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div onClick={() => onNavigate('live-monitoring')} className="card-hover p-4 cursor-pointer flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-teal-100 flex items-center justify-center"><Radio className="w-5 h-5 text-teal-600" /></div>
          <div className="flex-1"><p className="text-sm font-semibold text-navy-900">Live Monitoring</p><p className="text-xs text-gray-400">Compare normal vs current</p></div>
          <ChevronRight className="w-4 h-4 text-gray-300" />
        </div>
        <div onClick={() => onNavigate('ai-analysis')} className="card-hover p-4 cursor-pointer flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-navy-100 flex items-center justify-center"><Brain className="w-5 h-5 text-navy-600" /></div>
          <div className="flex-1"><p className="text-sm font-semibold text-navy-900">AI Analysis</p><p className="text-xs text-gray-400">Full pipeline view</p></div>
          <ChevronRight className="w-4 h-4 text-gray-300" />
        </div>
        <div onClick={() => onNavigate('maintenance')} className="card-hover p-4 cursor-pointer flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-warning-100 flex items-center justify-center"><AlertTriangle className="w-5 h-5 text-warning-600" /></div>
          <div className="flex-1"><p className="text-sm font-semibold text-navy-900">Maintenance</p><p className="text-xs text-gray-400">Predictive schedule</p></div>
          <ChevronRight className="w-4 h-4 text-gray-300" />
        </div>
      </div>
    </div>
  );
}
