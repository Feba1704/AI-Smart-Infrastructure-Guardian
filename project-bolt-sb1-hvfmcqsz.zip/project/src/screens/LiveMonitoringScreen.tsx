import { useState } from 'react';
import { Radio, Activity, Brain, AlertTriangle, TrendingUp, Waves, Gauge, Thermometer, Weight, ArrowRight } from 'lucide-react';
import type { Structure } from '@/types';
import type { PageId } from '@/types/nav';
import LineChart from '@/components/ui/LineChart';
import RiskBadge from '@/components/ui/Badge';
import ProgressRing from '@/components/ui/ProgressRing';

interface LiveMonitoringScreenProps {
  structures: Structure[];
  selectedStructure?: Structure;
  onSelectStructure: (s: Structure) => void;
  onNavigate: (page: PageId) => void;
}

const sensors = [
  { key: 'vibration' as const, label: 'Vibration', unit: 'mm/s', icon: Waves, color: '#3a5a9e' },
  { key: 'strain' as const, label: 'Strain', unit: 'µε', icon: Gauge, color: '#1f9d92' },
  { key: 'movement' as const, label: 'Movement', unit: 'mm', icon: Activity, color: '#8b5cf6' },
  { key: 'temperature' as const, label: 'Temperature', unit: '°C', icon: Thermometer, color: '#f59e0b' },
  { key: 'load' as const, label: 'Load', unit: '%', icon: Weight, color: '#ef4444' },
];

export default function LiveMonitoringScreen({ structures, selectedStructure, onSelectStructure, onNavigate }: LiveMonitoringScreenProps) {
  const [activeSensor, setActiveSensor] = useState<'vibration' | 'strain' | 'movement' | 'temperature' | 'load'>('vibration');
  const s = selectedStructure || structures[0];

  const normalData = s.learnedNormal.map(t => t[activeSensor]);
  const currentData = s.currentBehavior.map(t => t[activeSensor]);
  const labels = s.learnedNormal.map(t => t.timestamp);

  const deviations = sensors.map(sensor => {
    const n = s.learnedNormal.reduce((sum, t) => sum + t[sensor.key], 0) / s.learnedNormal.length;
    const c = s.currentBehavior.reduce((sum, t) => sum + t[sensor.key], 0) / s.currentBehavior.length;
    return { ...sensor, normalAvg: n, currentAvg: c, deviation: Math.abs(((c - n) / n) * 100) };
  });

  return (
    <div className="p-6 space-y-5 animate-fade-in">
      {/* Structure selector */}
      <div className="card p-4">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <Radio className="w-4.5 h-4.5 text-teal-600" style={{ width: 18, height: 18 }} />
            <span className="text-sm font-semibold text-navy-900">Monitoring:</span>
          </div>
          <select
            value={s.id}
            onChange={e => { const found = structures.find(x => x.id === e.target.value); if (found) onSelectStructure(found); }}
            className="bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm text-navy-900 focus:outline-none focus:ring-2 focus:ring-navy-400"
          >
            {structures.map(st => <option key={st.id} value={st.id}>{st.name} — {st.location}</option>)}
          </select>
          <RiskBadge level={s.riskLevel} />
          <div className="ml-auto flex items-center gap-2">
            <span className="relative flex">
              <span className="w-2 h-2 rounded-full bg-success-500 animate-ping-slow absolute" />
              <span className="w-2 h-2 rounded-full bg-success-500 relative" />
            </span>
            <span className="text-xs font-semibold text-success-600">Streaming · {s.activeSensors} sensors active</span>
          </div>
        </div>
      </div>

      {/* Comparison chart */}
      <div className="card p-5">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
          <div>
            <h3 className="section-title">Learned Normal Behavior vs Current Behavior</h3>
            <p className="text-xs text-gray-400 mt-0.5">AI model baseline compared with real-time sensor readings</p>
          </div>
          <div className="flex gap-1.5">
            {sensors.map(sensor => {
              const Icon = sensor.icon;
              return (
                <button
                  key={sensor.key}
                  onClick={() => setActiveSensor(sensor.key)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${activeSensor === sensor.key ? 'bg-navy-700 text-white' : 'bg-gray-50 text-gray-500 hover:bg-gray-100'}`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {sensor.label}
                </button>
              );
            })}
          </div>
        </div>

        <LineChart
          labels={labels}
          series={[
            { name: 'Learned Normal Behavior', data: normalData, color: '#94a3b8', dashed: true },
            { name: 'Current Behavior', data: currentData, color: sensors.find(x => x.key === activeSensor)?.color || '#3a5a9e' },
          ]}
          height={280}
          showLegend
          showArea
        />
      </div>

      {/* Deviation summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="card p-5">
          <h3 className="section-title mb-4">Deviation Summary</h3>
          <div className="space-y-3">
            {deviations.map(d => {
              const isDeviation = d.deviation > 10;
              return (
                <div key={d.key} className={`flex items-center gap-3 p-3 rounded-lg ${isDeviation ? 'bg-danger-50 border border-danger-100' : 'bg-gray-50 border border-gray-100'}`}>
                  <div className="w-9 h-9 rounded-lg bg-white border border-gray-200 flex items-center justify-center shrink-0">
                    <d.icon className="w-4.5 h-4.5" style={{ width: 18, height: 18, color: d.color }} />
                  </div>
                  <div className="flex-1">
                    <span className="text-xs font-semibold text-navy-900">{d.label}</span>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] text-gray-400">Normal: {d.normalAvg.toFixed(1)}</span>
                      <span className="text-[10px] text-gray-400">Current: {d.currentAvg.toFixed(1)}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className={`text-sm font-bold ${isDeviation ? 'text-danger-600' : 'text-success-600'}`}>
                      {d.deviation > 0 ? '+' : ''}{d.deviation.toFixed(1)}%
                    </span>
                    {isDeviation && <AlertTriangle className="w-3.5 h-3.5 text-danger-500 inline ml-1" />}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="card p-5 flex flex-col items-center justify-center">
          <h3 className="section-title mb-4">Overall Deviation</h3>
          <ProgressRing
            value={Math.round(s.deviationPercent)}
            size={120}
            stroke={8}
            color={s.deviationPercent > 20 ? '#ef4444' : s.deviationPercent > 10 ? '#f59e0b' : '#10b981'}
            label="From Normal"
            sublabel="across all sensors"
          />
          <div className="mt-4 text-center">
            <p className="text-xs text-gray-500">{s.deviationPercent > 20 ? 'Significant deviation detected' : s.deviationPercent > 10 ? 'Minor deviation observed' : 'Within normal range'}</p>
          </div>
        </div>

        <div className="card p-5">
          <h3 className="section-title mb-4">Anomaly Indicators</h3>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-gray-600">Anomaly Score</span>
                <span className="text-sm font-bold text-danger-600">{s.anomalyScore}/100</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full rounded-full bg-gradient-to-r from-warning-500 to-danger-500" style={{ width: `${s.anomalyScore}%` }} />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-gray-600">Risk Probability</span>
                <span className="text-sm font-bold text-danger-600">{s.riskProbability}%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full rounded-full bg-danger-500" style={{ width: `${s.riskProbability}%` }} />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-gray-600">Prediction Window</span>
                <span className="text-sm font-bold text-navy-700">{s.predictionWindow}</span>
              </div>
            </div>
          </div>
          <button onClick={() => onNavigate('ai-analysis')} className="btn-teal w-full mt-5 flex items-center justify-center gap-2">
            <Brain className="w-4 h-4" /> View AI Analysis <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* AI explanation */}
      <div className="card p-5 bg-gradient-to-br from-navy-50 to-teal-50 border-navy-100">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-500 flex items-center justify-center shrink-0">
            <Brain className="w-5 h-5 text-white" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-navy-900 mb-1">AI Explanation</h4>
            <p className="text-sm text-gray-600 leading-relaxed">{s.aiSummary}</p>
            <div className="flex items-center gap-2 mt-3">
              <TrendingUp className="w-4 h-4 text-teal-600" />
              <span className="text-xs font-semibold text-teal-700">Model confidence: {100 - s.anomalyScore > 50 ? 'High' : 'Moderate'} · Last trained: 2 hours ago</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
