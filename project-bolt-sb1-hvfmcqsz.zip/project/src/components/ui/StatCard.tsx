import type { LucideIcon } from 'lucide-react';

interface StatCardProps {
  icon: LucideIcon;
  label: string;
  value: string | number;
  sublabel?: string;
  trend?: number;
  color?: 'navy' | 'teal' | 'success' | 'warning' | 'danger';
}

const colorClasses = {
  navy: { bg: 'bg-navy-100', text: 'text-navy-600' },
  teal: { bg: 'bg-teal-100', text: 'text-teal-600' },
  success: { bg: 'bg-success-100', text: 'text-success-600' },
  warning: { bg: 'bg-warning-100', text: 'text-warning-600' },
  danger: { bg: 'bg-danger-100', text: 'text-danger-600' },
};

export default function StatCard({ icon: Icon, label, value, sublabel, trend, color = 'navy' }: StatCardProps) {
  const c = colorClasses[color];
  return (
    <div className="stat-card animate-slide-up">
      <div className="flex items-start justify-between">
        <div className={`w-11 h-11 rounded-xl ${c.bg} flex items-center justify-center`}>
          <Icon className={`w-5.5 h-5.5 ${c.text}`} style={{ width: 22, height: 22 }} />
        </div>
        {trend !== undefined && (
          <span className={`text-xs font-semibold ${trend >= 0 ? 'text-success-600' : 'text-danger-600'}`}>
            {trend >= 0 ? '↑' : '↓'} {Math.abs(trend)}%
          </span>
        )}
      </div>
      <div className="mt-3">
        <p className="metric-label">{label}</p>
        <p className="metric-value mt-0.5">{value}</p>
        {sublabel && <p className="text-xs text-gray-400 mt-1">{sublabel}</p>}
      </div>
    </div>
  );
}
