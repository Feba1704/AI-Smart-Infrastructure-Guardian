import { useState } from 'react';
import { Search, Filter, Building2, Construction, HardHat, Droplets, RadioTower, Landmark, MapPin, Cpu, ChevronRight } from 'lucide-react';
import type { Structure, StructureType, RiskLevel } from '@/types';
import RiskBadge from '@/components/ui/Badge';
import Sparkline from '@/components/ui/Sparkline';

interface InfrastructureScreenProps {
  structures: Structure[];
  onSelectStructure: (s: Structure) => void;
}

const typeIcons: Record<StructureType, typeof Building2> = {
  bridge: Construction,
  building: Building2,
  tunnel: HardHat,
  dam: Droplets,
  tower: RadioTower,
  stadium: Landmark,
};

const typeColors: Record<StructureType, string> = {
  bridge: 'bg-navy-100 text-navy-600',
  building: 'bg-teal-100 text-teal-600',
  tunnel: 'bg-gray-100 text-gray-600',
  dam: 'bg-blue-100 text-blue-600',
  tower: 'bg-purple-100 text-purple-600',
  stadium: 'bg-orange-100 text-orange-600',
};

const scoreColor = (score: number) => score >= 75 ? '#10b981' : score >= 50 ? '#f59e0b' : '#ef4444';

export default function InfrastructureScreen({ structures, onSelectStructure }: InfrastructureScreenProps) {
  const [search, setSearch] = useState('');
  const [filterRisk, setFilterRisk] = useState<RiskLevel | 'all'>('all');
  const [filterType, setFilterType] = useState<StructureType | 'all'>('all');

  const filtered = structures.filter(s => {
    const matchSearch = s.name.toLowerCase().includes(search.toLowerCase()) || s.location.toLowerCase().includes(search.toLowerCase()) || s.id.toLowerCase().includes(search.toLowerCase());
    const matchRisk = filterRisk === 'all' || s.riskLevel === filterRisk;
    const matchType = filterType === 'all' || s.type === filterType;
    return matchSearch && matchRisk && matchType;
  });

  return (
    <div className="p-6 space-y-5 animate-fade-in">
      {/* Filters */}
      <div className="card p-4">
        <div className="flex flex-col lg:flex-row gap-3 items-stretch lg:items-center">
          <div className="relative flex-1">
            <Search className="w-4.5 h-4.5 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" style={{ width: 18, height: 18 }} />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by name, location, or ID..."
              className="input-field pl-10"
            />
          </div>

          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-gray-400" />
            <div className="flex gap-1.5">
              {(['all', 'healthy', 'warning', 'critical'] as const).map(r => (
                <button
                  key={r}
                  onClick={() => setFilterRisk(r)}
                  className={`px-3 py-2 rounded-lg text-xs font-semibold transition-all ${filterRisk === r
                    ? r === 'healthy' ? 'bg-success-500 text-white' : r === 'warning' ? 'bg-warning-500 text-white' : r === 'critical' ? 'bg-danger-500 text-white' : 'bg-navy-700 text-white'
                    : 'bg-gray-50 text-gray-500 hover:bg-gray-100'}`}
                >
                  {r === 'all' ? 'All Risk' : r.charAt(0).toUpperCase() + r.slice(1)}
                </button>
              ))}
            </div>
          </div>

          <select
            value={filterType}
            onChange={e => setFilterType(e.target.value as StructureType | 'all')}
            className="bg-gray-50 border border-gray-300 rounded-lg px-3 py-2.5 text-sm text-navy-900 focus:outline-none focus:ring-2 focus:ring-navy-400"
          >
            <option value="all">All Types</option>
            <option value="bridge">Bridge</option>
            <option value="building">Building</option>
            <option value="tunnel">Tunnel</option>
            <option value="dam">Dam</option>
            <option value="tower">Tower</option>
            <option value="stadium">Stadium</option>
          </select>
        </div>
      </div>

      {/* Results count */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-500">
          Showing <span className="font-semibold text-navy-900">{filtered.length}</span> of {structures.length} structures
        </p>
      </div>

      {/* Structure cards grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map(s => {
          const Icon = typeIcons[s.type];
          return (
            <div
              key={s.id}
              onClick={() => onSelectStructure(s)}
              className="card-hover p-5 cursor-pointer group animate-slide-up"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${typeColors[s.type]}`}>
                    <Icon className="w-5.5 h-5.5" style={{ width: 22, height: 22 }} />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-navy-900 group-hover:text-teal-600 transition-colors">{s.name}</h3>
                    <p className="text-xs text-gray-400 flex items-center gap-1"><MapPin className="w-3 h-3" />{s.location}</p>
                  </div>
                </div>
                <RiskBadge level={s.riskLevel} />
              </div>

              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="metric-label">Health Score</p>
                  <p className="text-xl font-bold" style={{ color: scoreColor(s.healthScore) }}>{s.healthScore}<span className="text-xs text-gray-400 font-normal">/100</span></p>
                </div>
                <Sparkline data={s.trend.map(t => t.vibration)} color={scoreColor(s.healthScore)} width={80} height={32} />
              </div>

              <div className="grid grid-cols-3 gap-2 pt-3 border-t border-gray-100">
                <div>
                  <p className="text-[10px] text-gray-400 uppercase font-medium">ID</p>
                  <p className="text-xs font-semibold text-navy-700">{s.id}</p>
                </div>
                <div>
                  <p className="text-[10px] text-gray-400 uppercase font-medium">Sensors</p>
                  <p className="text-xs font-semibold text-navy-700">{s.activeSensors}/{s.sensorCount}</p>
                </div>
                <div>
                  <p className="text-[10px] text-gray-400 uppercase font-medium">Anomaly</p>
                  <p className="text-xs font-semibold text-navy-700">{s.anomalyScore}%</p>
                </div>
              </div>

              <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                <div className="flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 text-teal-500" />
                  <span className="text-[10px] text-gray-500">AI: {s.predictionWindow}</span>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-teal-500 group-hover:translate-x-0.5 transition-all" />
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="card p-12 text-center">
          <Search className="w-10 h-10 text-gray-300 mx-auto mb-3" />
          <p className="text-sm font-semibold text-gray-500">No structures found</p>
          <p className="text-xs text-gray-400 mt-1">Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
}
