import type { Structure } from '@/types';

interface InfrastructureMapProps {
  structures: Structure[];
  onSelectStructure?: (s: Structure) => void;
  selectedId?: string;
  height?: number;
}

const riskConfig = {
  healthy: { color: '#10b981', glow: '#6ee7b7' },
  warning: { color: '#f59e0b', glow: '#fcd34d' },
  critical: { color: '#ef4444', glow: '#fca5a5' },
};

const typeIcon: Record<string, string> = {
  bridge: '🌉',
  building: '🏢',
  tunnel: '🚇',
  dam: '💧',
  tower: '📡',
  stadium: '🏟️',
};

export default function InfrastructureMap({ structures, onSelectStructure, selectedId, height = 320 }: InfrastructureMapProps) {
  const latMin = 32, latMax = 49;
  const lngMin = -125, lngMax = -68;
  const w = 700, h = height;

  const project = (lat: number, lng: number) => ({
    x: ((lng - lngMin) / (lngMax - lngMin)) * (w - 60) + 30,
    y: h - ((lat - latMin) / (latMax - latMin)) * (h - 60) - 30,
  });

  const points = structures.map(s => ({ ...s, ...project(s.lat, s.lng) }));

  return (
    <div className="relative w-full overflow-hidden rounded-lg" style={{ height }}>
      <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-full">
        <defs>
          <pattern id="mapgrid" width="30" height="30" patternUnits="userSpaceOnUse">
            <path d="M 30 0 L 0 0 0 30" fill="none" stroke="#e2e8f0" strokeWidth="0.5" />
          </pattern>
          <radialGradient id="mapbg" cx="50%" cy="40%">
            <stop offset="0%" stopColor="#f0f9ff" />
            <stop offset="100%" stopColor="#e2e8f0" />
          </radialGradient>
        </defs>
        <rect width={w} height={h} fill="url(#mapbg)" />
        <rect width={w} height={h} fill="url(#mapgrid)" />

        {/* Simplified US outline */}
        <path
          d="M 30 80 Q 50 60 80 65 L 120 55 L 180 50 L 250 45 L 320 48 L 400 52 L 480 58 L 550 65 L 620 75 L 660 90 L 665 150 L 640 200 L 600 230 L 550 250 L 480 255 L 400 258 L 320 260 L 250 255 L 180 245 L 120 230 L 80 210 L 50 180 L 35 130 Z"
          fill="#f8fafc"
          stroke="#cbd5e1"
          strokeWidth="1.5"
          opacity="0.6"
        />

        {/* Connection lines */}
        {points.slice(0, -1).map((p, i) => {
          const next = points[i + 1];
          return (
            <line key={`line-${i}`} x1={p.x} y1={p.y} x2={next.x} y2={next.y} stroke="#e2e8f0" strokeWidth="1" strokeDasharray="3 3" />
          );
        })}

        {/* Structure pins */}
        {points.map(p => {
          const c = riskConfig[p.riskLevel];
          const isSelected = p.id === selectedId;
          return (
            <g key={p.id} onClick={() => onSelectStructure?.(p)} className="cursor-pointer">
              {p.riskLevel === 'critical' && (
                <circle cx={p.x} cy={p.y} r={14} fill={c.glow} opacity={0.3} className="animate-ping-slow" />
              )}
              <circle cx={p.x} cy={p.y} r={isSelected ? 12 : 9} fill={c.color} stroke="white" strokeWidth="2.5" style={{ transition: 'r 0.2s' }} />
              {isSelected && (
                <circle cx={p.x} cy={p.y} r={18} fill="none" stroke={c.color} strokeWidth="2" opacity="0.4" />
              )}
              <text x={p.x} y={p.y - 14} textAnchor="middle" className="fill-navy-800 pointer-events-none" style={{ fontSize: 9, fontWeight: 600 }}>
                {p.name.length > 18 ? p.name.slice(0, 16) + '…' : p.name}
              </text>
            </g>
          );
        })}
      </svg>

      {/* Legend overlay */}
      <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur-sm rounded-lg border border-gray-200 px-3 py-2 flex flex-col gap-1.5 shadow-sm">
        <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-success-500" /><span className="text-xs text-gray-600 font-medium">Healthy</span></div>
        <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-warning-500" /><span className="text-xs text-gray-600 font-medium">Warning</span></div>
        <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-danger-500" /><span className="text-xs text-gray-600 font-medium">Critical</span></div>
      </div>
    </div>
  );
}
