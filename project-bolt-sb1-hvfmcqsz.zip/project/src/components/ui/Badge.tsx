import type { RiskLevel } from '@/types';

interface BadgeProps {
  level: RiskLevel;
  size?: 'sm' | 'md';
  showDot?: boolean;
}

const config: Record<RiskLevel, { label: string; classes: string; dot: string }> = {
  healthy: { label: 'Healthy', classes: 'bg-success-100 text-success-700', dot: 'bg-success-500' },
  warning: { label: 'Warning', classes: 'bg-warning-100 text-warning-700', dot: 'bg-warning-500' },
  critical: { label: 'Critical', classes: 'bg-danger-100 text-danger-700', dot: 'bg-danger-500' },
};

export default function RiskBadge({ level, size = 'sm', showDot = true }: BadgeProps) {
  const c = config[level];
  const sizeClass = size === 'sm' ? 'px-2.5 py-0.5 text-xs' : 'px-3 py-1 text-sm';
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full font-semibold ${c.classes} ${sizeClass}`}>
      {showDot && <span className={`w-1.5 h-1.5 rounded-full ${c.dot}`} />}
      {c.label}
    </span>
  );
}
