export type PageId = 'dashboard' | 'infrastructure' | 'structure-details' | 'live-monitoring' | 'ai-analysis' | 'alerts' | 'maintenance' | 'reports';
