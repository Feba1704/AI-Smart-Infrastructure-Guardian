import { useState } from 'react';
import { Wrench, Calendar, DollarSign, AlertTriangle, CheckCircle2, Clock, ChevronRight, TrendingUp, FileBarChart } from 'lucide-react';
import type { MaintenanceItem } from '@/types';
import type { PageId } from '@/types/nav';

interface MaintenanceScreenProps {
  maintenanceItems: MaintenanceItem[];
  onNavigate: (page: PageId) => void;
}

const priorityConfig = {
  urgent: { label: 'Urgent', classes: 'bg-danger-100 text-danger-700 border-danger-200', dot: 'bg-danger-500' },
  high: { label: 'High', classes: 'bg-warning-100 text-warning-700 border-warning-200', dot: 'bg-warning-500' },
  medium: { label: 'Medium', classes: 'bg-teal-100 text-teal-700 border-teal-200', dot: 'bg-teal-500' },
  low: { label: 'Low', classes: 'bg-gray-100 text-gray-600 border-gray-200', dot: 'bg-gray-400' },
};

const statusConfig = {
  pending: { label: 'Pending', classes: 'bg-warning-50 text-warning-700 border-warning-200', icon: Clock },
  scheduled: { label: 'Scheduled', classes: 'bg-teal-50 text-teal-700 border-teal-200', icon: Calendar },
  'in-progress': { label: 'In Progress', classes: 'bg-navy-50 text-navy-700 border-navy-200', icon: Wrench },
  completed: { label: 'Completed', classes: 'bg-success-50 text-success-700 border-success-200', icon: CheckCircle2 },
};

export default function MaintenanceScreen({ maintenanceItems, onNavigate }: MaintenanceScreenProps) {
  const [filter, setFilter] = useState<'all' | 'urgent' | 'high' | 'medium' | 'low'>('all');

  const filtered = filter === 'all' ? maintenanceItems : maintenanceItems.filter(m => m.priority === filter);

  const sorted = [...filtered].sort((a, b) => {
    const order = { urgent: 0, high: 1, medium: 2, low: 3 };
    return order[a.priority] - order[b.priority];
  });

  const urgentCount = maintenanceItems.filter(m => m.priority === 'urgent').length;
  const highCount = maintenanceItems.filter(m => m.priority === 'high').length;
  const scheduledCount = maintenanceItems.filter(m => m.status === 'scheduled').length;
  const completedCount = maintenanceItems.filter(m => m.status === 'completed').length;

  return (
    <div className="p-6 space-y-5 animate-fade-in">
      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-danger-100 flex items-center justify-center"><AlertTriangle className="w-5 h-5 text-danger-600" /></div>
          <div><p className="metric-label">Urgent</p><p className="text-xl font-bold text-danger-600">{urgentCount}</p></div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-warning-100 flex items-center justify-center"><TrendingUp className="w-5 h-5 text-warning-600" /></div>
          <div><p className="metric-label">High Priority</p><p className="text-xl font-bold text-warning-600">{highCount}</p></div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-teal-100 flex items-center justify-center"><Calendar className="w-5 h-5 text-teal-600" /></div>
          <div><p className="metric-label">Scheduled</p><p className="text-xl font-bold text-teal-600">{scheduledCount}</p></div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-success-100 flex items-center justify-center"><CheckCircle2 className="w-5 h-5 text-success-600" /></div>
          <div><p className="metric-label">Completed</p><p className="text-xl font-bold text-success-600">{completedCount}</p></div>
        </div>
      </div>

      {/* Filter */}
      <div className="flex items-center gap-2">
        {(['all', 'urgent', 'high', 'medium', 'low'] as const).map(p => (
          <button
            key={p}
            onClick={() => setFilter(p)}
            className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all ${filter === p ? 'bg-navy-700 text-white' : 'bg-white border border-gray-200 text-gray-500 hover:bg-gray-50'}`}
          >
            {p === 'all' ? 'All Priorities' : priorityConfig[p].label}
          </button>
        ))}
      </div>

      {/* Maintenance cards */}
      <div className="space-y-3">
        {sorted.map(item => {
          const pc = priorityConfig[item.priority];
          const sc = statusConfig[item.status];
          const StatusIcon = sc.icon;
          return (
            <div key={item.id} className="card-hover p-5 animate-slide-up">
              <div className="flex items-start gap-4">
                <div className={`w-1 h-full min-h-[80px] rounded-full ${pc.dot}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-2">
                    <span className={`badge ${pc.classes} border`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${pc.dot}`} />
                      {pc.label}
                    </span>
                    <span className={`badge ${sc.classes} border`}>
                      <StatusIcon className="w-3 h-3" />
                      {sc.label}
                    </span>
                    <span className="text-[10px] text-gray-400 font-mono">{item.id}</span>
                  </div>
                  <h3 className="text-sm font-bold text-navy-900 mb-1">{item.structureName}</h3>
                  <p className="text-sm text-gray-600 mb-3">{item.predictedIssue}</p>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                      <p className="text-[10px] text-gray-400 uppercase font-semibold">Recommended Inspection</p>
                      <p className="text-xs text-navy-700 font-medium mt-0.5">{item.recommendedInspection}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-400 uppercase font-semibold">Urgency</p>
                      <p className="text-xs text-navy-700 font-medium mt-0.5">{item.urgency}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-400 uppercase font-semibold flex items-center gap-1"><DollarSign className="w-3 h-3" />Est. Cost</p>
                      <p className="text-xs text-navy-700 font-medium mt-0.5">{item.estimatedCost}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-400 uppercase font-semibold">Predicted Date</p>
                      <p className="text-xs text-navy-700 font-medium mt-0.5">{item.predictedDate}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 mt-3 pt-3 border-t border-gray-100">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] text-gray-400">AI Confidence:</span>
                      <span className="text-xs font-bold text-teal-600">{item.confidence}%</span>
                    </div>
                    {item.status === 'pending' && (
                      <button className="btn-secondary text-xs px-3 py-1.5 ml-auto">Schedule</button>
                    )}
                    <button onClick={() => onNavigate('reports')} className="btn-teal text-xs px-3 py-1.5 flex items-center gap-1">
                      <FileBarChart className="w-3.5 h-3.5" /> Report <ChevronRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
